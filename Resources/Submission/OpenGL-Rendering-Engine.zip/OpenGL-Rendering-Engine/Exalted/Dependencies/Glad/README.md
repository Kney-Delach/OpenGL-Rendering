# Glad
📚  | Contains the glad source I use for my rendering projects 

## Disclaimer 

The only piece of code in this repository that is created by me is the premake lua file, the rest was taken directly from [here](https://glad.dav1d.de/), and [this](https://github.com/Dav1dde/glad) is the official glad repo.
